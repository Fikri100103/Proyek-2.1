<?php
class BMI{
    public $berat;
    public $tinggi;

    function __construct($berat, $tinggi){
        $this->berat = $berat;
        $this->tinggi = $tinggi;
    }

    public function nilaiBMI(){
        $this->nilaiBMI = $berat / ($tinggi * $tinggi);
    }

    public function statusBMI(){
        if($this->nilaiBMI < 18.5){
            return "Kekurangan Berat Badan";
        } elseif($this->nilaiBMI >= 18.5 && $this->nilaiBMI <= 24.9){
            return "Normal (Ideal)";
        } elseif($this->nilaiBMI >= 25.0 && $this->nilaiBMI <= 29.9){
            return "Kelebihan Berat Badan";
        } elseif($this->nilaiBMI >= 30.0){
            return "Kegemukan (Obesitas)";
        }
    }
}
?>