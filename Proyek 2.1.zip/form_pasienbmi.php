<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Data BMI</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <h2>From Data BMI</h2>
    <hr>
    <div class="container">
        <form class="form-horizontal mt-3" method="POST" action="form_pasienbmi.php">
            <div class="form-group row">
                <label for="nama" class="col-4 col-form-label">Nama</label> 
                <div class="col-8">
                <input id="nama" name="nama" placeholder="Nama Lengkap" type="text" class="form-control" size="30">
                </div>
            </div>
            <div class="form-group row">
                <label for="berat" class="col-4 col-form-label">Berat</label> 
                <div class="col-8">
                <input id="berat" name="berat" placeholder="Berat (kg)" type="text" class="form-control" size="30">
                </div>
            </div>
            <div class="form-group row">
                <label for="tinggi" class="col-4 col-form-label">Tinggi</label> 
                <div class="col-8">
                <input id="tinggi" name="tinggi" placeholder="Tinggi (cm)" type="text" class="form-control">
                </div>
            </div> 
            <div class="form-group row">
                <div class="offset-4 col-8">
                <button name="proses" type="submit" class="btn btn-success">Simpan</button>
                </div>
            </div>
        </form>
        <br/>
        <?php
        require_once 'class_pasien.php';
        require_once 'class_bmi.php';
        require_once 'class_bmipasien.php';

        $psn1 = new Pasien("P001","Ahmad","L");
        $psn2 = new Pasien("P002","Rina","P");
        $psn3 = new Pasien("P003","Lutfi","L");

        $bmi1 = new BMI(69.8,169);
        $bmi1->nilai=24.7;
        $bmi1->status="Kelebihan Berat Badan";
        $bmi2 = new BMI(55.3,165);
        $bmi2->nilai=20.3;
        $bmi2->status="Normal (Ideal)";
        $bmi3 = new BMI(45.2,171);
        $bmi3->nilai=15.4;
        $bmi3->status="Kekurangan Berat Badan";

        $bmipsn1 = new BMIPasien($bmi1,"2022-01-10",$psn1);
        $bmipsn2 = new BMIPasien($bmi2,"2022-01-10",$psn2);
        $bmipsn3 = new BMIPasien($bmi3,"2022-01-11",$psn3);

        $data_pasien = [$bmipsn1,$bmipsn2,$bmipsn3];
        ?>
        <h1>Form BMI Pasien</h1>
        <table class="table" border="1" width="100%">
            <thead>
                <tr>
                    <th>No</th><th>Tanggal Periksa</th><th>Kode Pasien</th>
                    <th>Nama Pasien</th><th>Gender</th><th>Berat (kg)</th>
                    <th>Tinggi (cm)</th><th>Nilai BMI</th><th>Status BMI</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $nomor=1;
                    foreach($data_pasien as $obj){
                ?>
                    <tr>
                        <td><?=$nomor?></td>
                        <td><?=$obj->tanggal?></td>
                        <td><?=$obj->pasien->kode?></td>
                        <td><?=$obj->pasien->nama?></td>
                        <td><?=$obj->pasien->gender?></td>
                        <td><?=$obj->bmi->berat?></td>
                        <td><?=$obj->bmi->tinggi?></td>
                        <td><?=$obj->bmi->nilai?></td>
                        <td><?=$obj->bmi->status?></td>
                    </tr>
                <?php
                    $nomor++;
                    }
                ?>
            </tbody>
        </table>
        <?php
        if(isset($_POST['proses'])){
            $submit = $_POST['submit'];
            $nama = $_POST['nama']; 
            $berat = $_POST['berat'];
            $tinggi = $_POST['tinggi'];
            $nilaiBMI = $berat / (($tinggi / 0.01) * ($tinggi / 0.01));

            echo "<br/>Nama : ". $nama;
            echo "<br/>Berat : ". $berat;
            echo "<br/>Tinggi : ". $tinggi;
            echo "<br/>Nilai BMI : ". $nilaiBMI;
            
            $statusBMI = '';
            if($nilaiBMI < 18.5){
                $statusBMI = "Kekurangan Berat Badan";
            } elseif($nilaiBMI >= 18.5 && $nilaiBMI <= 24.9){
                $statusBMI = "Normal (Ideal)";
            } elseif($nilaiBMI >= 25.0 && $nilaiBMI <= 29.9){
                $statusBMI = "Kelebihan Berat Badan";
            } elseif($nilaiBMI >= 30.0){
                $statusBMI = "Kegemukan (Obesitas)";
            }
            echo "<br/>Status BMI : ". $statusBMI;
        } else{
            echo '------------- From Belum Diisi -------------';
        }
        echo '</table>';
        ?>
    </div>
    <footer>
        <p>Created by Khairul F. TI.NF;2022 </p>
    </footer>
</body>
</html>